import { LanguageProvider } from '@/components/language-provider'
import { Header } from '@/components/header'
import { Categories } from '@/components/categories'
import { DatePicker } from '@/components/date-picker'
import { EventCards } from '@/components/event-cards'
import { Footer } from '@/components/footer'

export default function Home() {
  return (
    <LanguageProvider>
      <div className="min-h-screen flex flex-col bg-background">
        <Header />
        <Categories />
        <DatePicker />
        <main className="flex-1">
          <EventCards />
        </main>
        <Footer />
      </div>
    </LanguageProvider>
  )
}
