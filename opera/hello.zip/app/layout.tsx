import type { Metadata, Viewport } from 'next'
import { Noto_Sans_Georgian } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const notoSansGeorgian = Noto_Sans_Georgian({ 
  subsets: ["georgian", "latin"],
  variable: '--font-georgian'
});

export const metadata: Metadata = {
  title: 'TKT.GE - ბილეთები ონლაინ',
  description: 'შეიძინეთ ბილეთები თეატრზე, ოპერაზე, კონცერტებზე და სხვა ღონისძიებებზე',
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ka" className="bg-background">
      <body className={`${notoSansGeorgian.variable} font-sans antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
