"use client"

import { useLanguage } from './language-provider'
import { Facebook, Instagram } from 'lucide-react'

export function Footer() {
  const { t } = useLanguage()

  const categories = [
    t.musicConcert,
    t.theaterCategory,
    t.operaCategory,
    t.sportCategory,
    t.international,
    t.omnibus,
    t.festival,
    t.children,
  ]

  const helpLinks = [
    t.onlineHelp,
    t.payment,
    t.forOrganizers,
    t.faq,
    t.phone,
    t.email,
    t.anonymousReview,
  ]

  const cinemaLinks = [
    t.cinematheater,
    t.kaveaTbilisiMall,
    t.kaveaIsani,
    t.kaveaGalleria,
    t.kaveaCityMall,
    t.kaveaGrandMallBatumi,
    t.iveriaKashuri,
  ]

  const carrierLinks = [
    t.tbilisiBatumi,
    t.tbilisiPoti,
    t.tbilisiKutaisi,
    t.tbilisiUreki,
    t.tbilisiOzurgeti,
  ]

  const flightLinks = [
    t.airlines,
    t.tbilisiIstanbul,
    t.tbilisiBerlin,
    t.tbilisiParis,
    t.tbilisiBarcelona,
    t.tbilisiBaku,
    t.scheduleWithExcursion,
  ]

  const partnerLogos = [
    { name: 'TNET', color: 'bg-foreground text-background' },
    { name: 'myauto', color: 'bg-orange-500 text-white' },
    { name: 'myparts', color: 'bg-green-500 text-white' },
    { name: 'myhome', color: 'bg-blue-500 text-white' },
    { name: 'mymarket', color: 'bg-yellow-500 text-foreground' },
    { name: 'myjobs', color: 'bg-purple-500 text-white' },
    { name: 'SuperApp', color: 'bg-foreground text-background' },
    { name: 'TKT.GE', color: 'bg-primary text-primary-foreground' },
    { name: 'SWOOP', color: 'bg-red-500 text-white' },
    { name: 'Livo', color: 'bg-blue-600 text-white' },
  ]

  return (
    <footer className="bg-card border-t border-border">
      {/* App download section */}
      <div className="border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <div className="flex items-center gap-3">
              {/* App Store button */}
              <button className="flex items-center gap-2 bg-foreground text-background px-4 py-2.5 rounded-lg min-h-[44px]">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
                </svg>
                <div className="text-left">
                  <div className="text-[10px] opacity-80">Download on the</div>
                  <div className="text-sm font-semibold">App Store</div>
                </div>
              </button>

              {/* Google Play button */}
              <button className="flex items-center gap-2 bg-foreground text-background px-4 py-2.5 rounded-lg min-h-[44px]">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M3,20.5V3.5C3,2.91 3.34,2.39 3.84,2.15L13.69,12L3.84,21.85C3.34,21.6 3,21.09 3,20.5M16.81,15.12L6.05,21.34L14.54,12.85L16.81,15.12M20.16,10.81C20.5,11.08 20.75,11.5 20.75,12C20.75,12.5 20.5,12.92 20.16,13.19L17.89,14.5L15.39,12L17.89,9.5L20.16,10.81M6.05,2.66L16.81,8.88L14.54,11.15L6.05,2.66Z"/>
                </svg>
                <div className="text-left">
                  <div className="text-[10px] opacity-80">GET IT ON</div>
                  <div className="text-sm font-semibold">Google Play</div>
                </div>
              </button>
            </div>

            <p className="text-sm text-muted-foreground text-center sm:text-left">
              {t.downloadApp}
            </p>
          </div>
        </div>
      </div>

      {/* Main footer content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
          {/* Categories */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">{t.categoriesTitle}</h3>
            <ul className="space-y-2">
              {categories.map((item, idx) => (
                <li key={idx}>
                  <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Help */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">{t.help}</h3>
            <ul className="space-y-2">
              {helpLinks.map((item, idx) => (
                <li key={idx}>
                  <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Cinema */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">{t.cinema}</h3>
            <ul className="space-y-2">
              {cinemaLinks.map((item, idx) => (
                <li key={idx}>
                  <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Carrier */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">{t.carrier}</h3>
            <ul className="space-y-2">
              {carrierLinks.map((item, idx) => (
                <li key={idx}>
                  <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Flights */}
          <div>
            <h3 className="font-semibold text-foreground mb-4">{t.flightsTitle}</h3>
            <ul className="space-y-2">
              {flightLinks.map((item, idx) => (
                <li key={idx}>
                  <a href="#" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Social links */}
        <div className="flex items-center gap-4 mt-8 pt-8 border-t border-border">
          <a href="#" className="p-3 rounded-full border border-border hover:bg-muted transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center">
            <Facebook className="w-5 h-5" />
          </a>
          <a href="#" className="p-3 rounded-full border border-border hover:bg-muted transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center">
            <Instagram className="w-5 h-5" />
          </a>
        </div>
      </div>

      {/* Legal links */}
      <div className="border-t border-border">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground underline">{t.rulesAndConditions}</a>
            <a href="#" className="hover:text-foreground underline">{t.privacyPolicy}</a>
            <a href="#" className="hover:text-foreground underline">{t.cookiePolicy}</a>
            <a href="#" className="hover:text-foreground underline">{t.termsOfUse}</a>
            <a href="#" className="hover:text-foreground underline">{t.tktGroup}</a>
          </div>
        </div>
      </div>

      {/* Partner logos */}
      <div className="border-t border-border bg-muted/50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex flex-wrap items-center justify-center gap-3">
            {partnerLogos.map((partner, idx) => (
              <div
                key={idx}
                className={`px-3 py-1.5 rounded text-xs font-semibold ${partner.color}`}
              >
                {partner.name}
              </div>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
