"use client"

import { useLanguage } from './language-provider'
import { ChevronLeft, ChevronRight, LayoutGrid, Bus, Drama, Music2, Trophy, Waves, Plane } from 'lucide-react'
import { useRef, useState } from 'react'

interface Category {
  id: string
  icon: React.ReactNode
  labelKey: keyof ReturnType<typeof import('@/lib/i18n').getTranslation>
  isNew?: boolean
  isActive?: boolean
  color?: string
}

export function Categories() {
  const { t } = useLanguage()
  const scrollRef = useRef<HTMLDivElement>(null)
  const [activeCategory, setActiveCategory] = useState<string>('opera')

  const categories: Category[] = [
    { id: 'categories', icon: <LayoutGrid className="w-5 h-5" />, labelKey: 'categories' },
    { id: 'transport', icon: <Bus className="w-5 h-5" />, labelKey: 'transport', isNew: true },
    { id: 'theater', icon: <Drama className="w-5 h-5" />, labelKey: 'theater' },
    { id: 'opera', icon: <Music2 className="w-5 h-5" />, labelKey: 'opera', isActive: true },
    { id: 'sport', icon: <Trophy className="w-5 h-5" />, labelKey: 'sport' },
    { id: 'sea', icon: <Waves className="w-5 h-5" />, labelKey: 'sea' },
    { id: 'flights', icon: <Plane className="w-5 h-5" />, labelKey: 'flights', color: 'accent' },
  ]

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 200
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      })
    }
  }

  return (
    <div className="bg-card border-b border-border">
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => scroll('left')}
            className="flex-shrink-0 p-2 rounded-full border border-border hover:bg-muted transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div
            ref={scrollRef}
            className="flex items-center gap-2 overflow-x-auto scrollbar-hide scroll-smooth"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {categories.map((category) => {
              const isActive = activeCategory === category.id
              const isAccent = category.color === 'accent'

              return (
                <button
                  key={category.id}
                  onClick={() => setActiveCategory(category.id)}
                  className={`
                    relative flex items-center gap-2 px-4 py-2.5 rounded-full whitespace-nowrap transition-all min-h-[44px]
                    ${isActive && !isAccent
                      ? 'bg-foreground text-background'
                      : isAccent
                        ? 'bg-accent text-accent-foreground'
                        : 'bg-muted text-foreground hover:bg-muted/80'
                    }
                  `}
                >
                  {category.isNew && (
                    <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-[10px] px-1.5 py-0.5 rounded-full">
                      {t.new}
                    </span>
                  )}
                  {category.icon}
                  <span className="text-sm font-medium">
                    {t[category.labelKey as keyof typeof t] as string}
                  </span>
                </button>
              )
            })}
          </div>

          <button
            onClick={() => scroll('right')}
            className="flex-shrink-0 p-2 rounded-full border border-border hover:bg-muted transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  )
}
