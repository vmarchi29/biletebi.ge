"use client"

import { useLanguage } from './language-provider'
import { ChevronLeft, ChevronRight, Calendar, ChevronDown } from 'lucide-react'
import { useState, useRef } from 'react'

interface DateItem {
  dayName: string
  dayNumber: number
  month: string
}

export function DatePicker() {
  const { t } = useLanguage()
  const scrollRef = useRef<HTMLDivElement>(null)
  const [selectedDate, setSelectedDate] = useState<number>(31)

  const today = new Date()
  const dates: DateItem[] = []

  // Generate 14 days
  for (let i = 0; i < 14; i++) {
    const date = new Date(today)
    date.setDate(today.getDate() + i)
    
    const dayNames = [t.days.sun, t.days.mon, t.days.tue, t.days.wed, t.days.thu, t.days.fri, t.days.sat]
    
    dates.push({
      dayName: dayNames[date.getDay()],
      dayNumber: date.getDate(),
      month: date.getMonth() === 4 ? t.may : t.june
    })
  }

  // Group by month
  const mayDates = dates.filter(d => d.month === t.may)
  const juneDates = dates.filter(d => d.month === t.june)

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 200
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      })
    }
  }

  return (
    <div className="bg-card border-b border-border">
      <div className="max-w-7xl mx-auto px-4 py-4">
        <div className="flex items-center gap-4">
          {/* Calendar icon */}
          <button className="flex-shrink-0 p-2 rounded-lg border border-border hover:bg-muted transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center">
            <Calendar className="w-5 h-5 text-muted-foreground" />
          </button>

          {/* Left arrow */}
          <button
            onClick={() => scroll('left')}
            className="flex-shrink-0 p-2 rounded-full hover:bg-muted transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {/* Date scrollable area */}
          <div
            ref={scrollRef}
            className="flex-1 overflow-x-auto scrollbar-hide"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            <div className="flex items-start gap-8">
              {/* May section */}
              {mayDates.length > 0 && (
                <div>
                  <p className="text-sm text-muted-foreground mb-2">{t.may}</p>
                  <div className="flex items-center gap-1">
                    {mayDates.map((date, idx) => (
                      <button
                        key={`may-${idx}`}
                        onClick={() => setSelectedDate(date.dayNumber)}
                        className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors min-w-[52px] min-h-[60px] ${
                          selectedDate === date.dayNumber
                            ? 'bg-primary text-primary-foreground'
                            : 'hover:bg-muted'
                        }`}
                      >
                        <span className={`text-xs ${selectedDate === date.dayNumber ? 'text-primary-foreground/80' : 'text-muted-foreground'}`}>
                          {date.dayName}
                        </span>
                        <span className="text-lg font-semibold">{date.dayNumber}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* June section */}
              {juneDates.length > 0 && (
                <div>
                  <p className="text-sm text-muted-foreground mb-2">{t.june}</p>
                  <div className="flex items-center gap-1">
                    {juneDates.map((date, idx) => (
                      <button
                        key={`june-${idx}`}
                        onClick={() => setSelectedDate(date.dayNumber)}
                        className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors min-w-[52px] min-h-[60px] ${
                          selectedDate === date.dayNumber
                            ? 'bg-primary text-primary-foreground'
                            : 'hover:bg-muted'
                        }`}
                      >
                        <span className={`text-xs ${selectedDate === date.dayNumber ? 'text-primary-foreground/80' : 'text-muted-foreground'}`}>
                          {date.dayName}
                        </span>
                        <span className="text-lg font-semibold">{date.dayNumber}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right arrow */}
          <button
            onClick={() => scroll('right')}
            className="flex-shrink-0 p-2 rounded-full hover:bg-muted transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          {/* Sort dropdown */}
          <button className="flex-shrink-0 flex items-center gap-2 px-4 py-2 rounded-lg border border-border hover:bg-muted transition-colors min-h-[44px]">
            <span className="text-sm text-muted-foreground">{t.sortBy}</span>
            <ChevronDown className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
      </div>
    </div>
  )
}
