"use client"

import { useLanguage } from './language-provider'
import Image from 'next/image'

interface Event {
  id: string
  title: string
  venue: string
  startDate: { day: number; month: string }
  endDate?: { day: number; month: string }
  image: string
  price?: number
  isSoldOut?: boolean
  category: 'theater' | 'opera'
}

export function EventCards() {
  const { t } = useLanguage()

  const events: Event[] = [
    {
      id: '1',
      title: 'თორაძის საერთაშორისო მუსიკალური ფესტივალი',
      venue: t.tbilisiOperaAndBallet,
      startDate: { day: 30, month: t.may },
      endDate: { day: 18, month: t.june },
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/7546f084-60b0-4813-89f2-f180ecdf7f1c.jpeg',
      price: 10,
      category: 'opera'
    },
    {
      id: '2',
      title: 'პოლონეთის ფრიდერიკ შოპენის სახელობის ბალტიის ფილარმონიის ორკესტრი',
      venue: t.tbilisiOperaAndBallet,
      startDate: { day: 1, month: t.june },
      endDate: { day: 2, month: t.june },
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/9cbdd71d-376e-49f0-9583-6fb3a6c2025a.jpeg',
      price: 20,
      category: 'opera'
    },
    {
      id: '3',
      title: 'ქეთო და კოტე',
      venue: t.tbilisiOperaAndBallet,
      startDate: { day: 5, month: t.june },
      endDate: { day: 21, month: t.june },
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/511a9fee-928d-4348-879f-9c9d4d1d2642.jpeg',
      isSoldOut: true,
      category: 'opera'
    },
    {
      id: '4',
      title: 'კარმენი',
      venue: t.tbilisiOperaAndBallet,
      startDate: { day: 13, month: t.june },
      endDate: { day: 14, month: t.june },
      image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/c0dc34a7-cfc9-4cf2-a98a-ce0253d78b2c.jpeg',
      price: 10,
      category: 'opera'
    },
  ]

  return (
    <div className="bg-background">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {events.map((event) => (
            <div
              key={event.id}
              className="group bg-card rounded-xl overflow-hidden border border-border hover:shadow-lg transition-shadow cursor-pointer"
            >
              {/* Image container */}
              <div className="relative aspect-[16/10] overflow-hidden bg-foreground/10">
                {/* Event image */}
                <Image
                  src={event.image}
                  alt={event.title}
                  fill
                  className="object-cover"
                  sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                />
                
                {/* Date badge */}
                <div className="absolute top-3 left-3 bg-foreground/90 text-background px-3 py-1.5 rounded-lg flex items-center gap-1 text-sm">
                  <span className="font-semibold">{event.startDate.day}</span>
                  {event.endDate && (
                    <>
                      <span>-</span>
                      <span className="font-semibold">{event.endDate.day}</span>
                    </>
                  )}
                  <span className="text-background/70 ml-1 text-xs">
                    {event.endDate ? event.endDate.month : event.startDate.month}
                  </span>
                </div>

                {/* Sold out badge */}
                {event.isSoldOut && (
                  <div className="absolute top-3 right-3 bg-primary text-primary-foreground px-3 py-1.5 rounded-lg text-sm font-medium">
                    {t.soldOut}
                  </div>
                )}
              </div>

              {/* Content */}
              <div className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-foreground truncate group-hover:text-primary transition-colors">
                      {event.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1 truncate">
                      {event.venue}
                    </p>
                  </div>
                  {event.price && (
                    <div className="flex-shrink-0 text-primary font-semibold">
                      {event.price}₾{t.priceFrom}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
